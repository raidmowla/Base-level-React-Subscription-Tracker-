import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../constants/theme';

// Returns how many days remain until the renewal date (can be negative
// if it already passed, which the UI treats as "overdue").
function daysUntil(dateString) {
  const today = new Date();
  const target = new Date(dateString);
  today.setHours(0, 0, 0, 0);
  target.setHours(0, 0, 0, 0);
  const diffMs = target.getTime() - today.getTime();
  return Math.round(diffMs / (1000 * 60 * 60 * 24));
}

export default function SubscriptionCard({ subscription, onDelete, onPress, currencySymbol = '$' }) {
  const days = daysUntil(subscription.nextRenewal);

  let badgeColor = COLORS.success;
  let badgeText = `${days}d left`;
  if (days < 0) {
    badgeColor = COLORS.danger;
    badgeText = 'Overdue';
  } else if (days <= 3) {
    badgeColor = COLORS.warning;
    badgeText = days === 0 ? 'Today' : `${days}d left`;
  }

  return (
    <TouchableOpacity
      style={styles.card}
      onPress={() => onPress?.(subscription)}
      activeOpacity={0.7}
    >
      <View style={styles.left}>
        <Text style={styles.name}>{subscription.name}</Text>
        <Text style={styles.category}>{subscription.category}</Text>
        <Text style={styles.date}>Renews {subscription.nextRenewal}</Text>
      </View>

      <View style={styles.right}>
        <Text style={styles.cost}>
          {currencySymbol}
          {Number(subscription.cost).toFixed(2)}
          <Text style={styles.cycle}>/{subscription.billingCycle === 'yearly' ? 'yr' : 'mo'}</Text>
        </Text>
        <View style={[styles.badge, { backgroundColor: badgeColor }]}>
          <Text style={styles.badgeText}>{badgeText}</Text>
        </View>
      </View>

      <TouchableOpacity
        style={styles.deleteButton}
        onPress={() => onDelete(subscription.id)}
        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      >
        <Ionicons name="trash-outline" size={20} color={COLORS.subtext} />
      </TouchableOpacity>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.card,
    borderRadius: 14,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  left: { flex: 1 },
  name: { fontSize: 16, fontWeight: '600', color: COLORS.text },
  category: { fontSize: 13, color: COLORS.subtext, marginTop: 2 },
  date: { fontSize: 12, color: COLORS.subtext, marginTop: 4 },
  right: { alignItems: 'flex-end', marginRight: 12 },
  cost: { fontSize: 16, fontWeight: '700', color: COLORS.text },
  cycle: { fontSize: 12, fontWeight: '400', color: COLORS.subtext },
  badge: {
    marginTop: 6,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  badgeText: { fontSize: 11, fontWeight: '600', color: '#fff' },
  deleteButton: { padding: 4 },
});
