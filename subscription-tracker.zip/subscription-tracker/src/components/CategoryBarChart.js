import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORS } from '../constants/theme';

const BAR_COLORS = [
  COLORS.primary,
  '#00B894',
  '#FDCB6E',
  '#E17055',
  '#0984E3',
  '#6C5CE7',
  '#D63031',
  '#00CEC9',
];

// data: [{ label: string, value: number }]
export default function CategoryBarChart({ data, currencySymbol = '$' }) {
  const maxValue = Math.max(...data.map((d) => d.value), 0.01);

  return (
    <View>
      {data.map((item, index) => {
        const widthPercent = (item.value / maxValue) * 100;
        return (
          <View key={item.label} style={styles.row}>
            <Text style={styles.label} numberOfLines={1}>
              {item.label}
            </Text>
            <View style={styles.barTrack}>
              <View
                style={[
                  styles.barFill,
                  {
                    width: `${Math.max(widthPercent, 4)}%`,
                    backgroundColor: BAR_COLORS[index % BAR_COLORS.length],
                  },
                ]}
              />
            </View>
            <Text style={styles.value}>
              {currencySymbol}
              {item.value.toFixed(2)}
            </Text>
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  label: { width: 90, fontSize: 13, color: COLORS.text, fontWeight: '500' },
  barTrack: {
    flex: 1,
    height: 14,
    backgroundColor: COLORS.border,
    borderRadius: 7,
    marginHorizontal: 10,
    overflow: 'hidden',
  },
  barFill: { height: '100%', borderRadius: 7 },
  value: { width: 62, fontSize: 13, fontWeight: '600', color: COLORS.text, textAlign: 'right' },
});
