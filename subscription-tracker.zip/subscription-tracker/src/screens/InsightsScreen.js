import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { COLORS } from '../constants/theme';
import CategoryBarChart from '../components/CategoryBarChart';
import { useSettings } from '../context/SettingsContext';

export default function InsightsScreen({ route }) {
  const subscriptions = route.params?.subscriptions ?? [];
  const { settings } = useSettings();

  const byCategory = useMemo(() => {
    const totals = {};
    subscriptions.forEach((s) => {
      const monthlyCost = s.billingCycle === 'yearly' ? s.cost / 12 : s.cost;
      totals[s.category] = (totals[s.category] || 0) + monthlyCost;
    });
    return Object.entries(totals)
      .map(([label, value]) => ({ label, value }))
      .sort((a, b) => b.value - a.value);
  }, [subscriptions]);

  const total = byCategory.reduce((sum, item) => sum + item.value, 0);

  const mostExpensive = useMemo(() => {
    if (subscriptions.length === 0) return null;
    return [...subscriptions].sort((a, b) => {
      const aMonthly = a.billingCycle === 'yearly' ? a.cost / 12 : a.cost;
      const bMonthly = b.billingCycle === 'yearly' ? b.cost / 12 : b.cost;
      return bMonthly - aMonthly;
    })[0];
  }, [subscriptions]);

  if (subscriptions.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>
          Add a few subscriptions to see your spending breakdown here.
        </Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.summaryCard}>
        <Text style={styles.summaryLabel}>Total monthly spend</Text>
        <Text style={styles.summaryValue}>
          {settings.currencySymbol}
          {total.toFixed(2)}
        </Text>
      </View>

      {mostExpensive && (
        <View style={styles.summaryCard}>
          <Text style={styles.summaryLabel}>Most expensive subscription</Text>
          <Text style={styles.summaryValue}>{mostExpensive.name}</Text>
        </View>
      )}

      <Text style={styles.sectionTitle}>By category</Text>
      <CategoryBarChart data={byCategory} currencySymbol={settings.currencySymbol} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  content: { padding: 20 },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    backgroundColor: COLORS.background,
  },
  emptyText: { fontSize: 14, color: COLORS.subtext, textAlign: 'center' },
  summaryCard: {
    backgroundColor: COLORS.card,
    borderRadius: 14,
    padding: 16,
    marginBottom: 14,
  },
  summaryLabel: { fontSize: 13, color: COLORS.subtext },
  summaryValue: { fontSize: 22, fontWeight: '700', color: COLORS.text, marginTop: 4 },
  sectionTitle: { fontSize: 15, fontWeight: '700', color: COLORS.text, marginTop: 6, marginBottom: 16 },
});
