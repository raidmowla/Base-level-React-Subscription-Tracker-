import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { COLORS } from '../constants/theme';
import { useSettings } from '../context/SettingsContext';

const REMINDER_OPTIONS = [1, 2, 3, 5, 7];
const CURRENCY_OPTIONS = ['$', '€', '£', '¥'];

export default function SettingsScreen() {
  const { settings, updateSettings } = useSettings();

  return (
    <View style={styles.container}>
      <Text style={styles.sectionTitle}>Remind me before renewal</Text>
      <Text style={styles.sectionSubtitle}>
        Applies to new or edited subscriptions. Existing reminders keep their
        original timing until you re-save that subscription.
      </Text>
      <View style={styles.optionsRow}>
        {REMINDER_OPTIONS.map((days) => (
          <TouchableOpacity
            key={days}
            style={[
              styles.optionPill,
              settings.reminderDays === days && styles.optionPillActive,
            ]}
            onPress={() => updateSettings({ reminderDays: days })}
          >
            <Text
              style={[
                styles.optionText,
                settings.reminderDays === days && styles.optionTextActive,
              ]}
            >
              {days} day{days > 1 ? 's' : ''}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={[styles.sectionTitle, { marginTop: 32 }]}>Currency</Text>
      <View style={styles.optionsRow}>
        {CURRENCY_OPTIONS.map((symbol) => (
          <TouchableOpacity
            key={symbol}
            style={[
              styles.optionPill,
              settings.currencySymbol === symbol && styles.optionPillActive,
            ]}
            onPress={() => updateSettings({ currencySymbol: symbol })}
          >
            <Text
              style={[
                styles.optionText,
                settings.currencySymbol === symbol && styles.optionTextActive,
              ]}
            >
              {symbol}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.card, padding: 20 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: COLORS.text },
  sectionSubtitle: { fontSize: 13, color: COLORS.subtext, marginTop: 6, marginBottom: 14 },
  optionsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  optionPill: {
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  optionPillActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  optionText: { fontSize: 14, color: COLORS.text, fontWeight: '500' },
  optionTextActive: { color: '#fff', fontWeight: '700' },
});
