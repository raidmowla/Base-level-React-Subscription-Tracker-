export const COLORS = {
  primary: '#6C5CE7',
  primaryDark: '#5849C4',
  background: '#F5F6FA',
  card: '#FFFFFF',
  text: '#2D3436',
  subtext: '#636E72',
  danger: '#E74C3C',
  success: '#00B894',
  warning: '#FDCB6E',
  border: '#DFE6E9',
};

export const CATEGORIES = [
  'Streaming',
  'Music',
  'Software',
  'Gaming',
  'Fitness',
  'News',
  'Cloud Storage',
  'Other',
];
