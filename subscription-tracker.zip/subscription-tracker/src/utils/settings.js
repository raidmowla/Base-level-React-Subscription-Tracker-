import AsyncStorage from '@react-native-async-storage/async-storage';

const SETTINGS_KEY = '@settings';

export const DEFAULT_SETTINGS = {
  reminderDays: 2, // how many days before renewal to notify
  currencySymbol: '$',
};

export async function loadSettings() {
  try {
    const json = await AsyncStorage.getItem(SETTINGS_KEY);
    return json ? { ...DEFAULT_SETTINGS, ...JSON.parse(json) } : DEFAULT_SETTINGS;
  } catch (e) {
    console.error('Failed to load settings', e);
    return DEFAULT_SETTINGS;
  }
}

export async function saveSettings(settings) {
  try {
    await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings', e);
  }
}
