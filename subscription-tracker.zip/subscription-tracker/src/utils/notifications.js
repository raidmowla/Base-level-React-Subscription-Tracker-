import * as Notifications from 'expo-notifications';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

// Ask the user for permission to send local notifications.
// Call this once when the app starts.
export async function registerForNotificationsAsync() {
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  return finalStatus === 'granted';
}

// Schedules a local reminder `reminderDays` before a subscription renews
// (defaults to 2 days if not provided, e.g. for older saved data).
// Returns the notification id (needed later to cancel it), or null
// if the renewal date is already in the past.
export async function scheduleRenewalReminder(subscription, reminderDays = 2) {
  try {
    const renewalDate = new Date(subscription.nextRenewal);
    const reminderDate = new Date(renewalDate);
    reminderDate.setDate(reminderDate.getDate() - reminderDays);
    reminderDate.setHours(9, 0, 0, 0);

    if (reminderDate <= new Date()) {
      return null;
    }

    const notificationId = await Notifications.scheduleNotificationAsync({
      content: {
        title: 'Subscription renewing soon',
        body: `${subscription.name} renews on ${subscription.nextRenewal} for $${subscription.cost}`,
      },
      trigger: reminderDate,
    });

    return notificationId;
  } catch (e) {
    console.error('Failed to schedule notification', e);
    return null;
  }
}

export async function cancelReminder(notificationId) {
  if (!notificationId) return;
  try {
    await Notifications.cancelScheduledNotificationAsync(notificationId);
  } catch (e) {
    console.error('Failed to cancel notification', e);
  }
}
