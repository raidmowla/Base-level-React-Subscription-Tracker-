import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEY = '@subscriptions';

export async function loadSubscriptions() {
  try {
    const json = await AsyncStorage.getItem(STORAGE_KEY);
    return json ? JSON.parse(json) : [];
  } catch (e) {
    console.error('Failed to load subscriptions', e);
    return [];
  }
}

export async function saveSubscriptions(subscriptions) {
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(subscriptions));
  } catch (e) {
    console.error('Failed to save subscriptions', e);
  }
}
