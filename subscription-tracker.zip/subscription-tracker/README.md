# Subscription Tracker

A base-level React Native (Expo) app for Android that helps solve **subscription
fatigue** — the problem of losing track of recurring charges (Netflix, Spotify,
gym memberships, SaaS tools, etc.) and getting surprised by renewals.

## Features
- Add **and edit** subscriptions with name, cost, billing cycle
  (monthly/yearly), renewal date (via a real native date picker), and category
- See total monthly spend at a glance (yearly plans are normalized to a
  monthly figure)
- List sorted by soonest renewal, with color-coded badges (green/yellow/red)
- Local push notification reminder before each renewal — **lead time is
  configurable** (1/2/3/5/7 days) in Settings
- **Insights screen** with a spend-by-category breakdown and your most
  expensive subscription
- **Settings screen** for reminder lead time and currency symbol
  ($ / € / £ / ¥)
- Data persists on-device via AsyncStorage — works fully offline
- Delete a subscription (also cancels its scheduled reminder)

## Project structure
```
subscription-tracker/
├── App.js                        # Navigation stack + providers, no screen logic
├── app.json                      # Expo/Android config
├── babel.config.js
├── package.json
└── src/
    ├── screens/
    │   ├── HomeScreen.js          # List, totals, delete, navigation to other screens
    │   ├── SubscriptionFormScreen.js  # Add AND edit (shared form, real date picker)
    │   ├── SettingsScreen.js      # Reminder lead time + currency
    │   └── InsightsScreen.js      # Spend-by-category chart
    ├── components/
    │   ├── SubscriptionCard.js    # Single subscription row (tap to edit)
    │   └── CategoryBarChart.js    # Lightweight bar chart (plain Views, no chart lib)
    ├── context/
    │   └── SettingsContext.js     # Shares settings across screens without prop drilling
    ├── constants/
    │   └── theme.js                # Colors + category list
    └── utils/
        ├── storage.js              # AsyncStorage load/save for subscriptions
        ├── settings.js              # AsyncStorage load/save for app settings
        └── notifications.js         # Schedule/cancel local reminders (configurable lead time)
```

### How navigation works
`App.js` sets up a `NativeStackNavigator` with four screens: `Home`,
`SubscriptionForm` (used for both adding and editing — it receives an
existing subscription via `route.params.subscription` when editing),
`Settings`, and `Insights`. The form screen doesn't talk to storage directly;
it navigates back to `Home` with the finished subscription in
`route.params.savedSubscription`, and `HomeScreen` is responsible for
persisting it and (re)scheduling its reminder. This keeps the "screen that
collects input" and "screen that owns the data" concerns separate.

## Setup

1. Install [Node.js](https://nodejs.org) (LTS) and the Expo CLI:
   ```bash
   npm install -g expo-cli
   ```

2. Install dependencies:
   ```bash
   cd subscription-tracker
   npm install
   ```

3. Run on Android:
   - **Easiest (no Android Studio needed):** install the **Expo Go** app on
     your Android phone from the Play Store, then run:
     ```bash
     npx expo start
     ```
     Scan the QR code shown in the terminal with the Expo Go app.

   - **Emulator / full native build:** with Android Studio and an emulator
     set up:
     ```bash
     npx expo run:android
     ```

## Notes / further next steps
- Sync data to the cloud (Firebase/Supabase) instead of only local storage,
  so it survives a reinstall or works across devices
- Add authentication if syncing across devices
- Add a "free trial ending" reminder type in addition to renewal reminders
- Let the user pick a custom renewal-reminder lead time per subscription,
  not just a single global setting
- Add a search/filter bar on the Home screen once the list gets long
- Export subscriptions to CSV

## Why this problem
Recurring subscriptions are easy to forget about and a well-documented source
of "subscription fatigue" — many people are paying for services they no
longer use, or get charged unexpectedly on renewal. This app gives a simple,
private (fully offline), at-a-glance way to stay on top of that.
